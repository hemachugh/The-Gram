// export const SOCKET_ENDPOINT = "http://localhost:4000";
export const SOCKET_ENDPOINT = "https://the-gram-e7fed57f3ab9.herokuapp.com";
